package problem;

public class User {
	private String pw;
	
	
	public User(String pw) {
		this.pw = pw;
	}


	public String getPw() {
		return pw;
	}



	
	
}
